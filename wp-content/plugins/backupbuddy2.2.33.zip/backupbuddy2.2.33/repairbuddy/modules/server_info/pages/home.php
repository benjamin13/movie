<?php
echo '<h3>Server Configuration</h3>';
require( 'view_tools-server.php' );

echo '<br>';

echo '<h3>File Permissions</h3>';
require( 'view_tools-permissions.php' );
?>